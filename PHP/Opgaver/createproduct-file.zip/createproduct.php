<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Edea skates</title>
</head>
<body class="light">
    <?php 
        include "includes/topmenu.php";

        include "includes/sidemenu.php";
    ?>
    
    <div class="content">
    <main>
        <section>
            <h1>Opret produkt</h1>

            <article>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <p>
                        <label for="productName">Produktnavn: </label>
                        <input type="text" name="productName">
                    </p>
                    <p>
                        <label for="productStars">Antal stjerner:</label>
                        <select name="productStars">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                        </select>
                    </p>
                    <p>
                        <label for="productDesc">Produktbeskrivelse: </label>
                        <textarea name="productDesc">
                        </textarea>
                    </p>
                    <p>
                        <label for="productStiff">Stivhed:</label>
                        <select name="productStiff">
                            <option value="48">48</option>
                            <option value="70">70</option>
                            <option value="85">85</option>
                            <option value="90">90</option>
                            <option value="95">95</option>
                        </select>
                    </p>
                    <p>
                        <label for="productSupports">Understøtter spring: </label>
                        <select name="productSupports" multiple size=6 class="multiselect">
                            <option value="Enkeltspring">Enkeltspring</option>
                            <option value="Axel">Axel</option>
                            <option value="Dobbeltspring">Dobbeltspring</option>
                            <option value="Triplespring">Triplespring</option>
                            <option value="Quadspring">Quadspring</option>
                            <option value="Alle danseniveauer">Alle danseniveauer</option>
                        </select>
                    </p>
                    <p>
                        <label for="productPrice">Pris: </label>
                        <input type="number" name="productPrice"> kr.
                    </p>
                    <p>
                        <label for="productPic">Produktbillede(r): </label>
                        <input type="file" name="productPic">
                    </p>
                    

                    <input type="submit" value="Opret produkt" name="createProductSubmit" class="submitbtn">
                </form>

            </article>

        </section>
    </main>

    <?php include "includes/footer.php"; ?>
</body>
</html>