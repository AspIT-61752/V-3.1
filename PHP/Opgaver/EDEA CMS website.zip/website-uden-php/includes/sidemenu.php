<nav class="side">
    <a href="index.php"><img src="img/edea-skates-logo.png" alt="Edea logo"></a>
    <ul>
        <li><a href="index.php">Forside</a></li>
        <li><a href="shop.php">Shop</a></li>
        <li><a href="createuser.php">Opret bruger</a></li>
        <li><a href="login.php">Login</a></li>        
    </ul>
</nav>